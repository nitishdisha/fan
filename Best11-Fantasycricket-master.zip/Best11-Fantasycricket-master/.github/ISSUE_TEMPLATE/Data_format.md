---
name: Data request
about: Suggest an way to organize or add more data for this project
title: ''
labels: ''
assignees: ''

---

**IS your data format related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Additional context**
Add any other context or screenshots about the feature request here.

**Check the appropriate choice**

* [ ] Organize data better
* [ ] Adding data to the dataset
